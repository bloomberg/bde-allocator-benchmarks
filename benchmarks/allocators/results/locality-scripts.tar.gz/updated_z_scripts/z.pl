#!/usr/bin/env perl
                      0         0               0               +0      0
                      0         0               0               +0      0
 use  strict;         0         0               0               +0      0
 use  strict;         0         0               0               +0      0
 use warnings;         0         0               0               +0      0
 use warnings;         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
  my $output_dir         0         0               0               +0      0
  my $output_dir         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
mkdir "$output_dir"         0         0               0               +0      0
mkdir "$output_dir"         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
 for       my         0         0               0               +0      0
 for       my         0         0               0               +0      0
        print         0         0               0               +0      0
        print         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
      open(my         0         0               0               +0      0
      open(my         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
      open(my         0         0               0               +0      0
      open(my         0         0               0               +0      0
           or         0         0               0               +0      0
           or         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
           my         0         0               0               +0      0
           my         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
     while(<$inH>)         0         0               0               +0      0
     while(<$inH>)         0         0               0               +0      0
     if(/0$/)         0         0               0               +0      0
     if(/0$/)         0         0               0               +0      0
        next;         0         0               0               +0      0
        next;         0         0               0               +0      0
            }         0         0               0               +0      0
            }         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
      if(/^#/         0         0               0               +0      0
      if(/^#/         0         0               0               +0      0
         push         0         0               0               +0      0
         push         0         0               0               +0      0
        next;         0         0               0               +0      0
        next;         0         0               0               +0      0
            }         0         0               0               +0      0
            }         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
       chomp;         0         0               0               +0      0
       chomp;         0         0               0               +0      0
           my         0         0               0               +0      0
           my         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
         push         0         0               0               +0      0
         push         0         0               0               +0      0
         push         0         0               0               +0      0
         push         0         0               0               +0      0
            }         0         0               0               +0      0
            }         0         0               0               +0      0
                      0         0               0               +0      0
                      0         0               0               +0      0
        print         0         0               0               +0      0
        print         0         0               0               +0      0
   }                  0         0               0               +0      0
   }                  0         0               0               +0      0
